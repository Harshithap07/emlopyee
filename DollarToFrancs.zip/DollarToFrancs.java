package com.nttdata.JavaBasics;
import java.util.Scanner;
public class DollarToFrancs {
		public static void main(String[] args)
		{
			float n=0.18f;
			System.out.println("1 franc=" +n+ "dollars");
			Scanner sc=new Scanner(System.in);
			System.out.println("enter french francs");
			float francs=sc.nextFloat();
			float dollars=francs*n;
			System.out.println("number of dollars are " + dollars);
			
			
		}
		

	}
		